// basic for loop in Java
package w1.syntaxReview.loops;

public class forLoop {
    public static void main(String[] args) {
        // for loop
        for (int i = 0; i < 10; i++) {
            System.out.println("i = " + i);
        }
    }
}

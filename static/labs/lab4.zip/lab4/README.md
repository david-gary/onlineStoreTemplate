# Week 3: Software Engineering Tools

## Overview

This week will teach you the basics of version control with Git. We'll also be using GitHub to host our repositories, and trying out the software practice of pair programming. The main lesson for this week is to get a sense of how version control can save you time and frustration, as well as to give you an idea of how to implement structural changes to the way you develop software that will easily catch and correct your mistakes. You will make mistakes. Software engineering is overwhelming. Plan to make them, and know how to fix them.

## Resources

- [StackOverflow Survey](https://insights.stackoverflow.com/survey/2021#overview)
- [Frying Pan Video](youtube.com/watch?v=YZ5tOe7y9x4)
- [Git and Github Resources](https://docs.github.com/en/get-started/quickstart/git-and-github-learning-resources)
- [Git Commands](https://git-scm.com/docs)
- [Dangit Git](https://dangitgit.com/en)
- [Git pro book](https://git-scm.com/book/en/v2)
- [Git Switch](https://www.git-tower.com/learn/git/commands/git-switch)
- [Git Cheat Sheet](https://education.github.com/git-cheat-sheet-education.pdf)
- [Do people know git?](https://dl.acm.org/doi/10.1145/3494518)

## Readings

- [Picking an IDE](https://code.pieces.app/blog/picking-the-best-ide-for-your-development-needs)
- [Why is Git Important?](https://towardsdatascience.com/what-is-git-and-why-is-it-so-important-dce559b27833)
- [Do people know how to use Git?](https://dl.acm.org/doi/10.1145/3494518)

## Assignments

- [lab4](./lab4)
- Git quiz
